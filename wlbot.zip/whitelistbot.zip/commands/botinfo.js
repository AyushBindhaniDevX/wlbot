const prefix = process.env.PREFIX
const Discord = require("discord.js")

module.exports = {
        name: 'botinfo',
        execute(message, args) {
                const embed = new Discord.MessageEmbed()
                        .setColor(process.env.EMBEDCOLOR)
                        .setAuthor("Bot Information", message.client.user.avatarURL())
                        .setDescription("**This is a project made by me(John5287#5287)and a user that wishes to remain silent.!**")
                        .addField("Bot Prefix","`" + process.env.PREFIX + "`")
                        .addField("Discord API Latency","**" + Math.round(message.client.ws.ping) + " ms**")
                        .addField("nothin to see here boys")
                        .setFooter("made with love")
                message.channel.send(embed)
        },
};